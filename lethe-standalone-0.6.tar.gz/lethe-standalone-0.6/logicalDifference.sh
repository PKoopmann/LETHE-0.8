java -cp lethe-standalone-0.6.jar uk.ac.man.cs.lethe.internal.application.LogicalDifferenceApplication $*
